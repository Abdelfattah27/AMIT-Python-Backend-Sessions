/// Dom manipulation 
// // getElementById

// const heading = document.getElementById("main-heading")
// console.log(heading)


// // getElementByClassName

// const lists = document.getElementsByClassName("list-item")
// const container = document.getElementsByClassName("container")

// console.log(lists.length)

// for(let i = 0 ; i < lists.length ; i ++) {
//     console.log(lists[i])
// }

// for (let list of lists) {
//     console.log(list)
// }

// console.log(container)

// getElementByTagName
// const lists = document.getElementsByTagName("li")
// console.log(lists) 
1

// querySelector 

// const element = document.querySelector("ul")
// const element = document.querySelector(".container")
// const element = document.querySelector("ul li")
// const element = document.querySelectorAll("ul li")


// const elements = document.querySelectorAll("ul li")
// let num = Number(prompt("What element you want to be black")) - 1
// elements[num].style.backgroundColor = "black"

// const liElement = document.querySelectorAll(".list-item")
// // liElement.innerText = "Hamada"
// // liElement.innerHTML = "<h1>Hamada</h1>"
// // liElement.textContent = "<h1>Hamada</h1>"
// console.log(liElement[2].innerText)
// console.log(liElement[2].innerHTML)
// console.log(liElement[2].textContent)

// style 
const elements = document.querySelectorAll("*")
for(let ele of elements) {
    ele.style.margin = "0px"
    ele.style.padding = "0px"
    ele.style.boxSizing = "border-box"
}

// const body = document.querySelector("body")
const body = document.body
console.log(body)
body.style.display = "flex"
body.style.justifyContent = "center"
body.style.alignItems = "center"
body.style.height = "100vh"
body.style.backgroundColor = "cadetblue"
body.style.fontFamily = "'Courier New', 'Courier', 'monospace'"


const container = document.querySelector(".container")
container.style.border = "5px solid white"
container.style.padding = "20px"
container.style.borderRadius = "20px"
container.style.width = "60%"